import ReactDOM from "react-dom";
import { BrowserRouter, Route } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
import "assets/styles/tailwind.css";

// views without layouts

import Index from "./views/Index";
import Team from "./page/Team";
import Layanan from "./page/Layanan";
import Tentang from "./page/Tentang";

function App(){
ReactDOM.render(
  <BrowserRouter>
      <Route path="/" element={<Index />} />
      <Route path="/team" element={<Team />}/>
      <Route path="/layanan" element={<Layanan />}/>
      <Route path="/tentang" element={<Tentang />}/>
      {/* add redirect for first page */}
  </BrowserRouter>,
  document.getElementById("root")
  );
}
export default App